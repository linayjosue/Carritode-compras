package com.example.carrocompras;

import java.io.Serializable;

public class Producto implements Serializable {


    String idProducto;
    String nomProducto;
    String decripcion;
    double precio;

    public Producto(String idProducto, String nomProducto, String decripcion, double precio) {
        this.idProducto = idProducto;
        this.nomProducto = nomProducto;
        this.decripcion = decripcion;
        this.precio = precio;
    }

    public String getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(String idProducto) {
        this.idProducto = idProducto;
    }

    public String getNomProducto() {
        return nomProducto;
    }

    public void setNomProducto(String nomProducto) {
        this.nomProducto = nomProducto;
    }

    public String getDecripcion() {
        return decripcion;
    }

    public void setDecripcion(String decripcion) {
        this.decripcion = decripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
