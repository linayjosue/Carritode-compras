package com.example.carrocompras;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    TextView tvCantProductos;
    Button btnVerCarro;
    RecyclerView rvListaProductos;
    AdaptadorProductos adaptador;
    List<Producto> listaProductos = new ArrayList<>();
    List<Producto> carroCompras = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        tvCantProductos = findViewById(R.id.tvCantProductos);
        btnVerCarro = findViewById(R.id.VerCarro);
        rvListaProductos = findViewById(R.id.rvListaProductos);
        rvListaProductos.setLayoutManager(new GridLayoutManager(MainActivity.this,1));

        listaProductos.add(new Producto("1","X box Series X", "descripción: PROCESADOR. CPU. CPU Zen 2 personaliza de 8 núcleos a 3,8 GHz (3,66 GHz con SMT", 8500.0));
        listaProductos.add(new Producto("2","Memoria USB 16 GB", "descripción: Memoria Kingston 16 gb", 480.0));
        listaProductos.add(new Producto("3","Motorola One", "descripción: Motorola One Android 10, 64 Gb ROM, 4 RAM", 4000.0));
        listaProductos.add(new Producto("4","Bocina Casco Darth Vader", "descripción: Bocina inalábrica bluetooth", 540.0));
        listaProductos.add(new Producto("5","Tester RJ45", "descripción: tester RJ45", 144.0));
        listaProductos.add(new Producto("6","Impresora Epson", "descripción: Impresora L4150 color 7500 b/n: 9000", 50.7));
        listaProductos.add(new Producto("7","Maouse Logitech G203", "descripción del producto 7", 500.6));
        listaProductos.add(new Producto("8","Laptop Asus X505ZA", "descripción del producto 8", 19000.6));

        adaptador = new AdaptadorProductos(MainActivity.this, tvCantProductos, btnVerCarro, listaProductos, carroCompras);
        rvListaProductos.setAdapter(adaptador);

    }
}